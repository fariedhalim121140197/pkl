<?php

namespace Laminas\Mail\Header\Exception;

use Laminas\Mail\Exception;

class BadMethodCallException extends Exception\BadMethodCallException implements ExceptionInterface
{
}
